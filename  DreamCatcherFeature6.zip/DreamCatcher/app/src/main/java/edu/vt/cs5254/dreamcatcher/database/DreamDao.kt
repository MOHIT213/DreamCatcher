package edu.vt.cs5254.dreamcatcher.database

import androidx.room.*
import edu.vt.cs5254.dreamcatcher.Dream
import edu.vt.cs5254.dreamcatcher.DreamEntry
import kotlinx.coroutines.flow.Flow
import java.util.UUID

@Dao
interface DreamDao {

    //Dream List Fragment
    @Query("select * from dream d JOIN dream_entry e ON d.id = e.dreamId order by d.lastUpdated desc")
    fun getDreams() : Flow<Map<Dream, List<DreamEntry>>>// --> MultiMap


    //Dream Detail Fragment
    @Query("select * from dream where id = (:id)")
    suspend fun getDream(id:UUID) : Dream

    @Query("select * from dream_entry where dreamId = (:dreamId)")
    suspend fun getDreamEntries(dreamId : UUID) : List<DreamEntry>

    @Transaction
    suspend fun getDreamWithEntries(id:UUID) : Dream{

        return getDream(id).apply { entries = getDreamEntries(id) }
    }

    @Update
    suspend fun updateDream(dream : Dream)

    @Insert
    suspend fun insertDreamEntry(dreamEntry: DreamEntry)

    @Query("delete from dream_entry where dreamId = (:dreamId)")
    suspend fun deleteEntriesFromDream(dreamId: UUID)

    @Transaction
    suspend fun updateDreamWithEntries(dream:Dream){
        deleteEntriesFromDream(dream.id)
        dream.entries.forEach {
            insertDreamEntry(it)
        }
        updateDream(dream)
    }

    @Insert
    suspend fun insertDream(dream : Dream)

    @Transaction
    suspend fun insertDreamWithEntries(dream : Dream){
        insertDream(dream)
        dream.entries.forEach { dreamEntry ->
            insertDreamEntry(dreamEntry)
        }
    }

    @Delete
    suspend fun deleteDream(dream : Dream)

    @Transaction
    suspend fun deleteDreamWithEntries(dream : Dream){
        deleteEntriesFromDream(dream.id)
        deleteDream(dream)
    }

    //Logic:
    //Using notations to define what to do. Then use transaction to combine the insert/update operations for dream and
    //also for dream entry. Then proceed to the Dream Repository to expose these methods . Then to the List View Model
    //to expose the method from the repository. Finally proceed to the List fragment to call the method from the Repository
    // Dream Dao -> Dream Repository -> View Model (List/Detail) -> Fragment (List/Detail)
}
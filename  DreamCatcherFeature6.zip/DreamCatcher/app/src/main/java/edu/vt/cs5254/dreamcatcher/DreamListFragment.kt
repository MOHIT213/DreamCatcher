package edu.vt.cs5254.dreamcatcher

import android.os.Bundle
import android.util.Log
import android.view.*
import androidx.core.view.MenuProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import edu.vt.cs5254.dreamcatcher.databinding.FragmentDreamListBinding
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch


class DreamListFragment : Fragment() {

    //Mohit Madhav Durge
    //PID: mohitdurge213

    private var _binding : FragmentDreamListBinding? = null
    private val binding
    get() = checkNotNull(_binding) { "FragmentDreamListBinding is null"}
    private val dreamListVM : DreamListViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentDreamListBinding.inflate(inflater,container,false)

        //for add new dream
        requireActivity().addMenuProvider(object : MenuProvider {
            override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
                menuInflater.inflate(R.menu.fragment_dream_list,menu)
            }
            override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
                return when(menuItem.itemId){
                    R.id.new_dream -> {
                        showNewDream()
                        true
                    }
                    else -> false
                }
            }

        },viewLifecycleOwner)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.dreamRecyclerView.layoutManager = LinearLayoutManager(context)

        //for enabling swipe feature to delete dream
        getItemTouchHelper().attachToRecyclerView(binding.dreamRecyclerView)

        //launch "something" in a coroutine scope and make sure its repeated when its started again
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED){
                //then collect from flow and watch/listen to the returned flow for any changes. If there are changes a new dream
                // i.e. it is returned and given to the adapter so the changes are reflected
                dreamListVM.dreams.collect{
                    if (it.isEmpty()){
                        binding.noDreamAddButton.visibility = View.VISIBLE
                        binding.noDreamText.visibility = View.VISIBLE
                    }
                    else{
                        binding.noDreamAddButton.visibility = View.GONE
                        binding.noDreamText.visibility = View.GONE
                    }
                    binding.dreamRecyclerView.adapter = DreamListAdapter(it) { dreamId ->
                        Log.w("DLF!!", "Clicked on dreamId: $dreamId")
                        findNavController().navigate(DreamListFragmentDirections.showDreamDetail(dreamId))
                    }
                }

            }
        }

        binding.noDreamAddButton.setOnClickListener {
            showNewDream()
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    private fun showNewDream(){

        //Since these 3 things have to happen one after the other, they need to be put in a coroutine scope (Race Condition).
        //Else adding a dream and navigating at the same time will not work.
        viewLifecycleOwner.lifecycleScope.launch {
            //Create new dream
            val newDream = Dream()
            //add to database
            dreamListVM.addDream(newDream)
            findNavController().navigate(DreamListFragmentDirections.showDreamDetail(newDream.id))
        }
    }

    //to Delete Dream
    private fun getItemTouchHelper() : ItemTouchHelper {

        return ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(0,ItemTouchHelper.LEFT){
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean = true

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val dreamHolder = viewHolder as DreamHolder
                val dreamToDelete = dreamHolder.boundDream
                //delete Dream from Database
                dreamListVM.deleteDream(dreamToDelete)

            }

        })

    }

}
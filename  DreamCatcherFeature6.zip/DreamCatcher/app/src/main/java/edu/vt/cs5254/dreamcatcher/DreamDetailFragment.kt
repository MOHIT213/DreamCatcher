package edu.vt.cs5254.dreamcatcher

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import java.util.*
import android.util.Log
import android.widget.Button
import androidx.core.widget.doOnTextChanged
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import edu.vt.cs5254.dreamcatcher.databinding.FragmentDreamDetailBinding
import android.text.format.DateFormat
import android.view.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.core.view.MenuProvider
import androidx.core.view.doOnLayout
import androidx.fragment.app.setFragmentResultListener
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import java.io.File


class DreamDetailFragment : Fragment() {

    //Mohit Madhav Durge
    //PID: mohitdurge213

    private val args: DreamDetailFragmentArgs by navArgs()

    private val dreamVM: DreamDetailViewModel by viewModels() {
        DreamDetailViewModelFactory(args.dreamId)
    }
    private lateinit var buttonList: List<Button>
    private val formatString: String = "'Last updated' yyyy-MM-dd 'at' hh:mm:ss a"
    private var _binding: FragmentDreamDetailBinding? = null
    private val binding
        get() = checkNotNull(_binding) {
            "Cannot access binding because it is null. Is the view visible?"

        }
    private val photoLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { tookPicture ->
        if (tookPicture) {
            dreamVM.dream.value?.let {
                binding.dreamPhoto.tag = null
                updatePhoto(it)
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentDreamDetailBinding.inflate(inflater, container, false)

        //share dream menu item
        requireActivity().addMenuProvider(
            object : MenuProvider {
                override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
                    menuInflater.inflate(R.menu.fragment_dream_detail, menu)

                    //if no camera, hide take_photo
                    if (photoLauncher.contract.createIntent(
                            requireContext(),
                            Uri.EMPTY
                        ).resolveActivity(requireActivity().packageManager) == null
                    ) {
                        menu.findItem(R.id.take_photo_menu).isVisible = false
                    }
                }

                override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
                    return when (menuItem.itemId) {
                        R.id.share_dream_menu -> {
                            dreamVM.dream.value?.let {
                                shareDream(it)
                            }
                            return true
                        }

                        R.id.take_photo_menu -> {
                            dreamVM.dream.value?.let { dream ->
                                val photoFile = File(
                                    requireActivity().filesDir,
                                    dream.photoFileName
                                )
                                val photoUri = FileProvider.getUriForFile(
                                    requireContext(),
                                    "edu.vt.cs5254.dreamcatcher.fileprovider",
                                    photoFile
                                )
                                photoLauncher.launch(photoUri)
                            }
                            return true
                        }

                        else -> false
                    }

                }

            },
            viewLifecycleOwner
        )//in lifecycle so that we dont get multiple menu items while transitioning back and forth from fragments


        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                dreamVM.dream.collect { dream ->
                    dream?.let {
                        updateView(it)
                    }

                }
            }
        }
        buttonList = listOf(
            binding.entry0Button,
            binding.entry1Button,
            binding.entry2Button,
            binding.entry3Button,
            binding.entry4Button
        )

        //Here we set listeners
        binding.dreamPhoto.setOnClickListener {
            dreamVM.dream.value?.let {
                findNavController().navigate(DreamDetailFragmentDirections.showPhotoDetail(it.photoFileName))

            }
        }

        binding.apply {
            titleText.doOnTextChanged { text, _, _, _ ->

                dreamVM.updateDream { oldDream ->
                    oldDream.copy(title = text.toString())
                        .apply { entries = oldDream.entries }
                }
            }
        }

        binding.deferredCheckbox.setOnClickListener {
            dreamVM.handleDeferredClick()
        }

        binding.fulfilledCheckbox.setOnClickListener {

            //If checked, then add new entry of isFulfilled to the current dream, else if unchecked then drop the isFulfilled entry.
            //These will help in setting the button isVisible status
            dreamVM.handleFulfilledClick()
        }

        binding.addReflectionButton.setOnClickListener {
            findNavController().navigate(DreamDetailFragmentDirections.addReflection())
        }


        setFragmentResultListener(
            ReflectionDialogFragment.REQUEST_REFLECTION
        ) { requestKey: String, bundle: Bundle ->

            val entryText =
                bundle.getString(ReflectionDialogFragment.BUNDLE_SET_REFLECTION) ?: ""
            dreamVM.updateDream {

                it.copy().apply {
                    entries = it.entries + DreamEntry(
                        dreamId = it.id,
                        text = entryText,
                        kind = DreamEntryKind.REFLECTION
                    )
                    //updateView(it)
                }
            }
        }

    }

    override fun onDestroy() {
        super.onDestroy()

        _binding = null
    }

    private fun getSharedDream(dream: Dream): String {

        val dateString = DateFormat.format(formatString, dream.lastUpdated)

        val reflectionString = dream.entries.filter {
            it.kind == DreamEntryKind.REFLECTION
        }.joinToString(separator = "\n") { it ->
            " * ${it.text}"
        }

        val reflectionsHeader = if (reflectionString != "") {
            getString(R.string.reflection_header)
        } else ""

        val conclusion = if (reflectionString != "") {
            if (dream.isFulfilled) {
                getString(R.string.conclusion) + " Fulfilled"
            } else if (dream.isDeferred) {
                getString(R.string.conclusion) + " Deferred"

            } else
                ""
        } else ""

        return dream.title + "\n" + dateString + "\n" + reflectionsHeader + "\n" + reflectionString + "\n" + conclusion

    }

    private fun shareDream(dream: Dream) {
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, getSharedDream(dream))
        }
        startActivity(share)

    }

    private fun updateView(dream: Dream) {

        //Set title text
        if (binding.titleText.text.toString() != dream.title) {
            binding.titleText.setText(dream.title)
        }


        //Set Checkboxes
        binding.fulfilledCheckbox.isChecked = dream.isFulfilled
        binding.fulfilledCheckbox.isEnabled = !dream.isDeferred
        binding.deferredCheckbox.isChecked = dream.isDeferred
        binding.deferredCheckbox.isEnabled = !dream.isFulfilled
        if (binding.deferredCheckbox.isEnabled) {
            binding.addReflectionButton.show()
        } else
            binding.addReflectionButton.hide()


        //Set buttons
        buttonList.forEach {
            it.visibility = View.GONE
        }

        dream.entries.zip(buttonList).forEach { (entry, button) ->
            button.displayEntry(entry, button)
        }

        binding.lastUpdatedText.text = DateFormat.format(formatString, dream.lastUpdated)

        updatePhoto(dream)

    }

    private fun updatePhoto(dream: Dream) {

        if (binding.dreamPhoto.tag != dream.photoFileName) {
            val photoFile = File(
                requireActivity().filesDir,
                dream.photoFileName
            )

            binding.dreamPhoto.doOnLayout { imageView ->

                if (photoFile.exists()) {
                    val bitmap = getScaledBitmap(
                        photoFile.path,
                        imageView.width,
                        imageView.height
                    )
                    binding.dreamPhoto.setImageBitmap(bitmap)
                    binding.dreamPhoto.tag = dream.photoFileName
                } else {
                    binding.dreamPhoto.setImageBitmap(null)
                    binding.dreamPhoto.tag = null
                }
            }
        }
    }


}